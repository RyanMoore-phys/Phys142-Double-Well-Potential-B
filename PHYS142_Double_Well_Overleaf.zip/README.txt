PHYS 142/242 final project manuscript — Overleaf source

Upload this ZIP directly using Overleaf -> New Project -> Upload Project.
Set main.tex as the main document and pdfLaTeX as the compiler.
The document uses REVTeX 4.2 (APS Physical Review Letters style), with references embedded in main.tex. Compile twice to resolve cross-references. All six PNG figures are identical to the saved notebook outputs from the supplied repository snapshot.

Main text and figures: four pages; references and appendices follow.

Before submission: verify author order/affiliation, review the group AI-use disclosure and add all actual tools/prompts/conversation links, and decide whether to perform additional targeted simulation checks. The manuscript reports the saved notebook results, not an independent full simulation rerun. No repository changes were made.
